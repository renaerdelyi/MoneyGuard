import React from "react";
import Balance from "../components/Balance/Balance";


const HomeTab = () => {
  return (
    <div>
      <Balance />
    </div>
  );
};

export default HomeTab;
