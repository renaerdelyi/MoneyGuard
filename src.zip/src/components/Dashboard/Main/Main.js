import { MainStyled } from './Main.styled';
// import { DinamicSidebar } from '../SideBar/DinamicSidebar';
import { TransactionsTable } from '../TransactionsTable/TransactionsTable';

export const Main = () => {
  return (
    <MainStyled>
      {/* <DinamicSidebar /> */}
      <TransactionsTable />
    </MainStyled>
  );
};
