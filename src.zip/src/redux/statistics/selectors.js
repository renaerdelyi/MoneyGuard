export default function selectSummary(state) {
  return state.statistics.summary;
}
