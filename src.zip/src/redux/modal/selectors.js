export const selectModalTypeState = state => state.modal.modalType;
export const selectModalState = state => state.modal.isModalOpen;
